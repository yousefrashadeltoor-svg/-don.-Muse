// Package the real Next.js standalone server for the Android embedded Node runtime.
// The website source/UI is not rewritten or exported to a simplified static page.
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const root = process.cwd();
const standalone = path.join(root, '.next', 'standalone');
const staticDir = path.join(root, '.next', 'static');
const publicDir = path.join(root, 'public');
const assetsDir = path.join(root, 'android', 'app', 'src', 'main', 'assets');
const stage = path.join(root, '.android-server-stage');
const archive = path.join(assetsDir, 'donmuse-server.zip');
const checksumFile = path.join(assetsDir, 'donmuse-server.sha256');

if (!fs.existsSync(path.join(standalone, 'server.js'))) {
  throw new Error('Missing .next/standalone/server.js. Run `npm run build` first.');
}
if (!fs.existsSync(staticDir)) throw new Error('Missing .next/static.');

fs.rmSync(stage, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });
fs.cpSync(standalone, stage, { recursive: true, dereference: true });

const copyIfPresent = (from, to) => {
  if (fs.existsSync(from)) fs.cpSync(from, to, { recursive: true, dereference: true });
};
copyIfPresent(staticDir, path.join(stage, '.next', 'static'));
copyIfPresent(publicDir, path.join(stage, 'public'));
// Only ship an intentional SQL seed snapshot. Never copy a developer/build-time
// PGlite database directory into the APK or a web update bundle.
const seedFile = path.join(root, 'data', 'seed.sql');
if (fs.existsSync(seedFile)) {
  fs.mkdirSync(path.join(stage, 'data'), { recursive: true });
  fs.copyFileSync(seedFile, path.join(stage, 'data', 'seed.sql'));
}

// The npm ffmpeg-static artifact is a Linux host binary, not an Android binary.
// It is not runnable in the embedded Android Node runtime and is not needed to
// start the original Next.js site. Keep the JS package metadata but omit its
// host executable to avoid shipping a large incompatible binary.
const ffmpegPackage = path.join(stage, 'node_modules', 'ffmpeg-static');
if (fs.existsSync(ffmpegPackage)) {
  try {
    const ffmpegMeta = JSON.parse(fs.readFileSync(path.join(ffmpegPackage, 'package.json'), 'utf8'));
    const ffmpegBinary = typeof ffmpegMeta.bin === 'string' ? ffmpegMeta.bin : null;
    if (ffmpegBinary) fs.rmSync(path.resolve(ffmpegPackage, ffmpegBinary), { force: true });
  } catch (error) {
    console.warn('Could not inspect optional ffmpeg-static binary:', error.message);
  }
}

// Do not ship development-only files or host-specific build caches.
for (const rel of ['.next/cache', 'node_modules/.cache', 'node_modules/typescript', 'node_modules/eslint']) {
  fs.rmSync(path.join(stage, rel), { recursive: true, force: true });
}
fs.mkdirSync(assetsDir, { recursive: true });
fs.rmSync(archive, { force: true });

// `zip` is available on GitHub's Ubuntu runners and preserves the standalone tree.
execFileSync('zip', ['-q', '-r', '-X', archive, '.'], { cwd: stage, stdio: 'inherit' });
const digest = createHash('sha256').update(fs.readFileSync(archive)).digest('hex');
fs.writeFileSync(checksumFile, `${digest}\n`, 'utf8');
fs.rmSync(stage, { recursive: true, force: true });
console.log(`Android server bundle: ${archive}`);
console.log(`SHA-256: ${digest}`);
