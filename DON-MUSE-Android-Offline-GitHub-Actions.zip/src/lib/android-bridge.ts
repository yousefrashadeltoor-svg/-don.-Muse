export interface AndroidPlaybackState {
  isPlaying: boolean;
  positionSeconds: number;
  durationSeconds: number;
  title?: string;
  artist?: string;
  mediaId?: string;
}

export interface DonMuseNativeBridge {
  isReady(): boolean;
  loadAndPlay(title: string, artist: string, url: string, artworkUrl: string, autoplay: boolean): void;
  setQueue(queueJson: string, currentIndex: number, autoplay: boolean, positionSeconds: number): void;
  selectQueueItem(index: number, autoplay: boolean): void;
  play(): void;
  pause(): void;
  stop(): void;
  seekTo(seconds: number): void;
  setVolume(value: number): void;
  setPlaybackRate(value: number): void;
  getPlaybackState(): string;
}

declare global {
  interface Window {
    DonMuseNative?: DonMuseNativeBridge;
  }
}

export function getAndroidBridge(): DonMuseNativeBridge | null {
  if (typeof window === "undefined") return null;
  const bridge = window.DonMuseNative;
  if (!bridge) return null;
  try {
    return bridge.isReady() ? bridge : null;
  } catch {
    return null;
  }
}

export function getAndroidPlaybackState(): AndroidPlaybackState | null {
  const bridge = getAndroidBridge();
  if (!bridge) return null;
  try {
    const state = JSON.parse(bridge.getPlaybackState()) as Partial<AndroidPlaybackState>;
    return {
      isPlaying: Boolean(state.isPlaying),
      positionSeconds: Number(state.positionSeconds) || 0,
      durationSeconds: Number(state.durationSeconds) || 0,
      title: state.title,
      artist: state.artist,
      mediaId: state.mediaId,
    };
  } catch {
    return null;
  }
}
