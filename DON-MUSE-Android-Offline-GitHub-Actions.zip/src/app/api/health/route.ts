import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Local readiness endpoint for the embedded Android website runtime. */
export function GET() {
  return NextResponse.json({ ok: true, app: "DON MUSE", runtime: "local" }, {
    headers: { "Cache-Control": "no-store" },
  });
}
