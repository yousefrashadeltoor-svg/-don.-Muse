#include <jni.h>
#include <node.h>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <unistd.h>

static std::string fromJString(JNIEnv* env, jstring value) {
    if (value == nullptr) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (chars == nullptr) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_fm_donmuse_app_runtime_NodeBridge_startNodeWithArguments(
    JNIEnv* env,
    jobject /* this */,
    jobjectArray arguments,
    jstring workingDirectory,
    jstring dataDirectory,
    jstring cacheDirectory
) {
    const std::string cwd = fromJString(env, workingDirectory);
    const std::string dataDir = fromJString(env, dataDirectory);
    const std::string cacheDir = fromJString(env, cacheDirectory);

    if (!cwd.empty() && chdir(cwd.c_str()) != 0) return 71;

    // Next.js standalone binds only to the device loopback interface.
    setenv("NODE_ENV", "production", 1);
    setenv("NEXT_TELEMETRY_DISABLED", "1", 1);
    setenv("PORT", "3000", 1);
    setenv("HOSTNAME", "127.0.0.1", 1);
    setenv("DATABASE_URL", "local", 1);
    setenv("DONMUSE_ANDROID", "1", 1);
    setenv("DONMUSE_DATA_DIR", dataDir.c_str(), 1);
    setenv("DONMUSE_CACHE_DIR", cacheDir.c_str(), 1);
    setenv("TMPDIR", cacheDir.c_str(), 1);
    setenv("NODE_COMPILE_CACHE", cacheDir.c_str(), 1);
    setenv("NODE_COMPILE_CACHE_PORTABLE", "1", 1);
    setenv("UV_THREADPOOL_SIZE", "4", 1);
    setenv("NODE_OPTIONS", "--max-old-space-size=640", 1);

    const jsize count = env->GetArrayLength(arguments);
    if (count <= 0) return 72;

    std::vector<std::string> nativeArgs;
    nativeArgs.reserve(static_cast<size_t>(count));
    for (jsize i = 0; i < count; ++i) {
        auto item = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        nativeArgs.push_back(fromJString(env, item));
        env->DeleteLocalRef(item);
    }

    std::vector<char*> argv;
    argv.reserve(nativeArgs.size());
    for (auto& arg : nativeArgs) argv.push_back(arg.data());

    // node::Start owns the Node event loop and blocks until the local server exits.
    return static_cast<jint>(node::Start(static_cast<int>(argv.size()), argv.data()));
}
