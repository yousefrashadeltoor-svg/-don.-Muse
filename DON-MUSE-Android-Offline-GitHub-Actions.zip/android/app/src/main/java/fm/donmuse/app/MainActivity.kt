package fm.donmuse.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import fm.donmuse.app.playback.PlaybackService
import fm.donmuse.app.runtime.LocalNodeService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import android.provider.MediaStore
import android.widget.Toast

private const val LOCAL_ORIGIN = "http://127.0.0.1:3000"
private val AppBackground = Color(0xFF030304)
private val AppAccent = Color(0xFF1DB954)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var webView: WebView? = null
    private var serverReady by mutableStateOf(false)
    private var serverError by mutableStateOf(false)

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // Start the embedded Node server and connect Media3 for system controls/widgets.
        ContextCompat.startForegroundService(this, Intent(this, LocalNodeService::class.java))
        val sessionToken = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()

        watchLocalServer()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = AppBackground, surface = Color(0xFF111114), primary = AppAccent)) {
                if (serverReady) {
                    DonMuseWebView(
                        onCreated = { webView = it },
                        onExternalUrl = { openExternal(it) }
                    )
                } else {
                    LocalServerLoading(error = serverError)
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val view = webView
                if (view != null && view.canGoBack()) view.goBack() else finish()
            }
        })
    }

    private fun watchLocalServer() {
        lifecycleScope.launch {
            val ready = withContext(Dispatchers.IO) {
                repeat(180) {
                    if (checkServer()) return@withContext true
                    delay(500)
                }
                false
            }
            serverReady = ready
            serverError = !ready
            if (ready) requestWebUpdateCheck()

            var wasReady = ready
            while (true) {
                delay(1800)
                val currentReady = withContext(Dispatchers.IO) { checkServer() }
                if (currentReady != wasReady) {
                    serverReady = currentReady
                    serverError = !currentReady
                    if (currentReady) {
                        webView?.post { webView?.reload() }
                        requestWebUpdateCheck()
                    }
                    wasReady = currentReady
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (serverReady) requestWebUpdateCheck()
    }

    private fun requestWebUpdateCheck() {
        runCatching {
            val intent = Intent(this, LocalNodeService::class.java).setAction(LocalNodeService.ACTION_CHECK_WEB_UPDATE)
            ContextCompat.startForegroundService(this, intent)
        }
    }

    private fun checkServer(): Boolean = runCatching {
        val connection = (URL("$LOCAL_ORIGIN/api/health").openConnection() as HttpURLConnection)
        connection.connectTimeout = 700
        connection.readTimeout = 1200
        connection.requestMethod = "GET"
        try {
            connection.responseCode in 200..299
        } finally {
            connection.disconnect()
        }
    }.getOrDefault(false)

    private fun openExternal(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    override fun onDestroy() {
        webView?.apply {
            stopLoading()
            loadUrl("about:blank")
            removeAllViews()
            destroy()
        }
        webView = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@androidx.compose.runtime.Composable
private fun DonMuseWebView(onCreated: (WebView) -> Unit, onExternalUrl: (String) -> Unit) {
    AndroidView(
        modifier = Modifier.fillMaxSize().background(AppBackground),
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(android.graphics.Color.rgb(3, 3, 4))
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.javaScriptCanOpenWindowsAutomatically = false
                settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                settings.userAgentString = settings.userAgentString + " DONMUSE-Android"
                WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
                addJavascriptInterface(DonMuseNativeBridge(context), "DonMuseNative")
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val uri = request.url
                        if (!request.isForMainFrame) return false
                        val isLocal = uri.host == "127.0.0.1" && uri.port == 3000
                        if (isLocal) return false
                        onExternalUrl(uri.toString())
                        return true
                    }
                }
                setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
                    if (url.startsWith("$LOCAL_ORIGIN/")) {
                        // DownloadManager runs in a separate system process and cannot
                        // reach this app's 127.0.0.1 server. Fetch local downloads in-app.
                        downloadLocalFile(context, url, contentDisposition, mimeType)
                    } else if (url.startsWith("https://") || url.startsWith("http://")) {
                        runCatching {
                            val request = android.app.DownloadManager.Request(Uri.parse(url))
                            request.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            request.setMimeType(mimeType)
                            request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                            request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS,
                                URLUtil.guessFileName(url, contentDisposition, mimeType))
                            context.getSystemService(android.app.DownloadManager::class.java).enqueue(request)
                        }
                    } else {
                        onExternalUrl(url)
                    }
                })
                loadUrl(LOCAL_ORIGIN)
                onCreated(this)
            }
        },
        update = { }
    )
}

private fun downloadLocalFile(context: Context, url: String, contentDisposition: String?, mimeType: String?) {
    val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType).ifBlank { "DON-MUSE-download" }
    Thread({
        var savedToDownloads = false
        try {
            val request = Request.Builder().url(url).get().build()
            OkHttpClient().newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IllegalStateException("Download failed: HTTP ${response.code}")
                val body = response.body ?: throw IllegalStateException("Download response was empty")
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeType ?: "application/octet-stream")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/DON MUSE")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Could not create the download file")
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { output -> body.byteStream().use { input -> input.copyTo(output) } }
                            ?: throw IllegalStateException("Could not open the download file")
                        val completed = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                        context.contentResolver.update(uri, completed, null, null)
                        savedToDownloads = true
                    } catch (error: Throwable) {
                        context.contentResolver.delete(uri, null, null)
                        throw error
                    }
                } else {
                    val base = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
                    val directory = File(base, "DON MUSE").apply { mkdirs() }
                    File(directory, fileName).outputStream().use { output -> body.byteStream().use { input -> input.copyTo(output) } }
                    savedToDownloads = true
                }
            }
        } catch (error: Throwable) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(context, "تعذّر تنزيل الملف: ${error.message ?: "خطأ غير معروف"}", Toast.LENGTH_LONG).show()
            }
            return@Thread
        }
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            Toast.makeText(
                context,
                if (savedToDownloads) "تم حفظ الملف في Downloads / DON MUSE" else "اكتمل التنزيل",
                Toast.LENGTH_LONG
            ).show()
        }
    }, "donmuse-local-download").start()
}

@androidx.compose.runtime.Composable
private fun LocalServerLoading(error: Boolean) {
    Box(Modifier.fillMaxSize().background(AppBackground), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("DON MUSE", color = Color.White, fontSize = 26.sp)
            Spacer(Modifier.height(18.dp))
            if (!error) CircularProgressIndicator(color = AppAccent)
            Spacer(Modifier.height(14.dp))
            Text(
                if (error) "The local website engine did not start. Close and reopen DON MUSE."
                else "Starting your offline music workspace…",
                color = Color(0xFF9A9AA2), fontSize = 13.sp
            )
        }
    }
}
