package fm.donmuse.app.playback

import android.app.PendingIntent
import android.os.Handler
import android.os.Looper
import android.content.ComponentName
import android.content.Intent
import android.appwidget.AppWidgetManager
import android.util.Log
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import fm.donmuse.app.MainActivity
import fm.donmuse.app.R
import fm.donmuse.app.widget.MiniPlayerWidget
import fm.donmuse.app.widget.NowPlayingWidget
import org.json.JSONObject

/** Native Media3 session used by Android notifications, lock screen, Bluetooth and widgets. */
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastWidgetRefreshAt = 0L
    private val snapshotTicker = object : Runnable {
        override fun run() {
            val current = player
            if (current != null) {
                updateSnapshot(current)
                val now = android.os.SystemClock.elapsedRealtime()
                if (now - lastWidgetRefreshAt >= 1800L) {
                    lastWidgetRefreshAt = now
                    refreshWidgets()
                }
            }
            mainHandler.postDelayed(this, 400L)
        }
    }
    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            updateSnapshot(player)
            refreshWidgets()
        }
    }

    companion object {
        @Volatile var player: ExoPlayer? = null
            private set
        @Volatile var session: MediaSession? = null
            private set
        @Volatile var snapshotJson: String = "{\"isPlaying\":false,\"positionSeconds\":0,\"durationSeconds\":0}"
            private set
    }

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this).setHandleAudioBecomingNoisy(true).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
            addListener(listener)
        }
        val sessionActivity = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builtSession = MediaSession.Builder(this, exo).setSessionActivity(sessionActivity).build()
        mediaSession = builtSession
        player = exo
        session = builtSession
        updateSnapshot(exo)
        mainHandler.post(snapshotTicker)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mainHandler.removeCallbacks(snapshotTicker)
        player?.removeListener(listener)
        player?.release()
        mediaSession?.release()
        mediaSession = null
        player = null
        session = null
        snapshotJson = "{\"isPlaying\":false,\"positionSeconds\":0,\"durationSeconds\":0}"
        super.onDestroy()
    }

    private fun updateSnapshot(p: Player) {
        val duration = if (p.duration > 0) p.duration else 0L
        snapshotJson = JSONObject()
            .put("isPlaying", p.isPlaying)
            .put("positionSeconds", (p.currentPosition.coerceAtLeast(0L) / 1000.0))
            .put("durationSeconds", (duration / 1000.0))
            .put("title", p.mediaMetadata.title?.toString() ?: "")
            .put("artist", p.mediaMetadata.artist?.toString() ?: "")
            .put("mediaId", p.currentMediaItem?.mediaId ?: "")
            .toString()
    }

    private fun refreshWidgets() {
        runCatching {
            val manager = AppWidgetManager.getInstance(this)
            val now = ComponentName(this, NowPlayingWidget::class.java)
            NowPlayingWidget().onUpdate(this, manager, manager.getAppWidgetIds(now))
            val mini = ComponentName(this, MiniPlayerWidget::class.java)
            MiniPlayerWidget().onUpdate(this, manager, manager.getAppWidgetIds(mini))
        }.onFailure { Log.w("DONMUSE_WIDGET", "Widget refresh failed", it) }
    }
}

/** Operations shared by the WebView bridge and the app widgets. */
object Playback {
    fun playSingle(url: String, title: String, artist: String, artworkUrl: String, autoplay: Boolean = true) {
        val p = PlaybackService.player ?: return
        val media = buildMediaItem(url, title, artist, artworkUrl, "0")
        p.setMediaItem(media)
        p.prepare()
        p.playWhenReady = autoplay
    }

    fun setQueue(items: List<NativeQueueItem>, currentIndex: Int, autoplay: Boolean, positionMs: Long = 0L) {
        val p = PlaybackService.player ?: return
        if (items.isEmpty()) return
        val mediaItems = items.mapIndexed { index, item ->
            buildMediaItem(item.url, item.title, item.artist, item.artworkUrl, item.id.ifBlank { index.toString() })
        }
        val safeIndex = currentIndex.coerceIn(0, mediaItems.lastIndex)
        p.setMediaItems(mediaItems, safeIndex, positionMs.coerceAtLeast(0L))
        p.prepare()
        p.playWhenReady = autoplay
    }

    fun selectQueueItem(index: Int, autoplay: Boolean) {
        val p = PlaybackService.player ?: return
        if (p.mediaItemCount == 0 || index !in 0 until p.mediaItemCount) return
        if (p.currentMediaItemIndex != index) p.seekTo(index, 0L)
        p.playWhenReady = autoplay
        if (autoplay) p.prepare()
    }

    private fun buildMediaItem(url: String, title: String, artist: String, artworkUrl: String, mediaId: String): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle("DON MUSE")
            .apply { if (artworkUrl.isNotBlank()) setArtworkUri(android.net.Uri.parse(artworkUrl)) }
            .build()
        return MediaItem.Builder().setMediaId(mediaId).setUri(url).setMediaMetadata(metadata).build()
    }

    fun play() { PlaybackService.player?.play() }
    fun pause() { PlaybackService.player?.pause() }
    fun toggle() {
        val p = PlaybackService.player ?: return
        if (p.isPlaying) p.pause() else p.play()
    }
    fun next() { PlaybackService.player?.seekToNext() }
    fun previous() { PlaybackService.player?.seekToPrevious() }
    fun stop() { PlaybackService.player?.stop() }
    fun seekTo(positionMs: Long) { PlaybackService.player?.seekTo(positionMs.coerceAtLeast(0L)) }
    fun setVolume(volume: Float) { PlaybackService.player?.volume = volume.coerceIn(0f, 1f) }
    fun setPlaybackRate(rate: Float) { PlaybackService.player?.playbackParameters = PlaybackParameters(rate.coerceIn(0.5f, 3f)) }
}

data class NativeQueueItem(
    val id: String,
    val title: String,
    val artist: String,
    val url: String,
    val artworkUrl: String
)
