package fm.donmuse.app.runtime

/** JNI entry point into the Bionic-built Node.js Mobile runtime. */
class NodeBridge {
    external fun startNodeWithArguments(
        arguments: Array<String>,
        workingDirectory: String,
        dataDirectory: String,
        cacheDirectory: String
    ): Int

    companion object {
        init {
            System.loadLibrary("node")
            System.loadLibrary("donmuse_node_bridge")
        }
    }
}
