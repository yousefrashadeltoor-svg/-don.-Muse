package fm.donmuse.app.runtime

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import fm.donmuse.app.R
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/** Keeps the original Next.js standalone server running locally for the WebView. */
class LocalNodeService : Service() {
    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("DON MUSE is ready offline")
            .setContentText("Keeping your local music app available")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, 0)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CHECK_WEB_UPDATE && started.get() && updateCheckStarted.compareAndSet(false, true)) {
            Thread({
                try {
                    val appDir = File(filesDir, "donmuse-server")
                    val versionFile = File(filesDir, "donmuse-server.version")
                    if (appDir.resolve("server.js").isFile && tryDownloadWebUpdate(appDir, versionFile)) {
                        Log.i(TAG, "New website bundle installed; restarting isolated Node runtime")
                        // LocalNodeService runs in :donmuse_node, so this restart does not
                        // stop the Android Media3 playback service in the main app process.
                        Process.killProcess(Process.myPid())
                    }
                } catch (error: Throwable) {
                    Log.w(TAG, "Web bundle update check failed", error)
                } finally {
                    updateCheckStarted.set(false)
                }
            }, "donmuse-web-update").start()
        }
        if (started.compareAndSet(false, true)) {
            Thread({
                try {
                    val appDir = prepareServerBundle()
                    val dataDir = File(filesDir, "donmuse-data/pglite").apply { mkdirs() }
                    val cacheDir = File(filesDir, "donmuse-cache").apply { mkdirs() }
                    Log.i(TAG, "Starting embedded DON MUSE server from ${appDir.absolutePath}")
                    val code = NodeBridge().startNodeWithArguments(
                        arrayOf("node", "server.js"),
                        appDir.absolutePath,
                        dataDir.absolutePath,
                        cacheDir.absolutePath
                    )
                    Log.e(TAG, "Embedded Node server exited with code $code; requesting sticky-service restart")
                    // A Node runtime owns its process event loop. Restart it in a fresh
                    // Android service process instead of initializing a second runtime
                    // in the same process.
                    Process.killProcess(Process.myPid())
                } catch (error: Throwable) {
                    Log.e(TAG, "Could not start local DON MUSE server", error)
                    started.set(false)
                }
            }, "donmuse-node-runtime").apply { isDaemon = false }.start()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun prepareServerBundle(): File {
        val appDir = File(filesDir, "donmuse-server")
        val versionFile = File(filesDir, "donmuse-server.version")
        val embeddedVersion = assets.open("donmuse-server.sha256").bufferedReader().use { it.readText().trim() }

        // Attempt a web-only update first. It changes the bundled website/server code,
        // never the APK, and leaves the last known-good local bundle intact on failure.
        tryDownloadWebUpdate(appDir, versionFile)

        if (appDir.resolve("server.js").isFile && versionFile.exists()) return appDir

        installEmbeddedBundle(appDir, embeddedVersion)
        return appDir
    }

    private fun installEmbeddedBundle(appDir: File, version: String) {
        val staging = File(filesDir, "donmuse-server-staging")
        staging.deleteRecursively()
        staging.mkdirs()
        assets.open("donmuse-server.zip").use { input ->
            ZipInputStream(input.buffered()).use { zip -> extractZip(zip, staging) }
        }
        require(File(staging, "server.js").isFile) { "Embedded server.js is missing" }
        replaceDirectory(staging, appDir)
        File(filesDir, "donmuse-server.version").writeText(version)
    }

    private fun tryDownloadWebUpdate(appDir: File, versionFile: File): Boolean {
        val manifestUrl = fm.donmuse.app.BuildConfig.WEB_BUNDLE_MANIFEST_URL
        if (manifestUrl.isBlank() || !manifestUrl.startsWith("https://github.com/")) return false
        var connection: HttpURLConnection? = null
        try {
            connection = URL(manifestUrl).openConnection() as HttpURLConnection
            connection.connectTimeout = 4500
            connection.readTimeout = 7000
            connection.instanceFollowRedirects = true
            val manifestText = connection.inputStream.bufferedReader().use { it.readText() }
            val manifest = JSONObject(manifestText)
            val version = manifest.getString("version")
            val sha256 = manifest.getString("sha256").lowercase()
            val bundleUrl = manifest.getString("bundleUrl")
            require(bundleUrl.startsWith("https://github.com/")) { "Only GitHub release bundles are accepted" }
            if (versionFile.exists() && versionFile.readText().trim() == version && appDir.resolve("server.js").isFile) return false

            val tmpZip = File(cacheDir, "donmuse-web-update.zip")
            val download = URL(bundleUrl).openConnection() as HttpURLConnection
            try {
                download.connectTimeout = 15000
                download.readTimeout = 120000
                download.instanceFollowRedirects = true
                download.inputStream.use { input -> FileOutputStream(tmpZip).use { output -> input.copyTo(output) } }
            } finally {
                download.disconnect()
            }
            require(tmpZip.length() in 1..(350L * 1024L * 1024L)) { "DON MUSE update bundle has an invalid size" }
            require(sha256(tmpZip) == sha256) { "DON MUSE update checksum mismatch" }

            val staging = File(filesDir, "donmuse-server-update")
            staging.deleteRecursively()
            staging.mkdirs()
            ZipInputStream(tmpZip.inputStream().buffered()).use { extractZip(it, staging) }
            require(File(staging, "server.js").isFile) { "Updated server.js is missing" }
            replaceDirectory(staging, appDir)
            versionFile.writeText(version)
            tmpZip.delete()
            Log.i(TAG, "Installed web-only update $version")
            return true
        } catch (error: Exception) {
            // Offline first launch or failed update: keep the bundled/previous version.
            Log.i(TAG, "No web update applied; using the local bundle: ${error.message}")
            return false
        } finally {
            connection?.disconnect()
        }
    }

    private fun extractZip(zip: ZipInputStream, destination: File) {
        val root = destination.canonicalFile
        var entry = zip.nextEntry
        while (entry != null) {
            val output = File(destination, entry.name)
            require(output.canonicalFile.path.startsWith(root.path + File.separator) || output.canonicalFile == root) {
                "Unsafe path in app bundle"
            }
            if (entry.isDirectory) {
                output.mkdirs()
            } else {
                output.parentFile?.mkdirs()
                FileOutputStream(output).use { zip.copyTo(it) }
            }
            zip.closeEntry()
            entry = zip.nextEntry
        }
    }

    private fun replaceDirectory(staging: File, destination: File) {
        val backup = File(filesDir, "donmuse-server-previous")
        backup.deleteRecursively()
        if (destination.exists() && !destination.renameTo(backup)) {
            throw IllegalStateException("Cannot move the current local website bundle")
        }
        if (!staging.renameTo(destination)) {
            if (backup.exists()) backup.renameTo(destination)
            throw IllegalStateException("Cannot activate the new local website bundle")
        }
        backup.deleteRecursively()
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "DON MUSE local app", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Local website engine and offline playback support" }
        )
    }

    companion object {
        private const val TAG = "DONMUSE_NODE"
        private const val CHANNEL_ID = "donmuse_local_engine"
        private const val NOTIFICATION_ID = 7301
        const val ACTION_CHECK_WEB_UPDATE = "fm.donmuse.app.CHECK_WEB_UPDATE"
        private val started = AtomicBoolean(false)
        private val updateCheckStarted = AtomicBoolean(false)
    }
}
