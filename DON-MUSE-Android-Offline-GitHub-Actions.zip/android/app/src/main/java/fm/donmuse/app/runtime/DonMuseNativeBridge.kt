package fm.donmuse.app.runtime

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import fm.donmuse.app.playback.Playback
import fm.donmuse.app.playback.PlaybackService
import fm.donmuse.app.playback.NativeQueueItem
import org.json.JSONArray

/** Small, origin-local bridge for native playback; no generic filesystem or shell access. */
class DonMuseNativeBridge(context: Context) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun isReady(): Boolean = true

    @JavascriptInterface
    fun loadAndPlay(title: String, artist: String, url: String, artworkUrl: String, autoplay: Boolean) {
        if (!isAllowedMediaUrl(url)) return
        main.post {
            if (PlaybackService.player == null) {
                androidx.core.content.ContextCompat.startForegroundService(
                    appContext,
                    android.content.Intent(appContext, fm.donmuse.app.playback.PlaybackService::class.java)
                )
                main.postDelayed({ Playback.playSingle(url, title, artist, artworkUrl, autoplay) }, 700)
            } else {
                Playback.playSingle(url, title, artist, artworkUrl, autoplay)
            }
        }
    }

    @JavascriptInterface
    fun setQueue(queueJson: String, currentIndex: Int, autoplay: Boolean, positionSeconds: Double) {
        val parsed = runCatching { JSONArray(queueJson) }.getOrNull() ?: return
        val items = buildList {
            for (i in 0 until parsed.length()) {
                val item = parsed.optJSONObject(i) ?: continue
                val url = item.optString("url")
                if (!isAllowedMediaUrl(url)) continue
                add(NativeQueueItem(
                    id = item.optString("id"),
                    title = item.optString("title", "DON MUSE"),
                    artist = item.optString("artist", ""),
                    url = url,
                    artworkUrl = item.optString("artworkUrl", "")
                ))
            }
        }
        if (items.isEmpty()) return
        main.post {
            if (PlaybackService.player == null) {
                androidx.core.content.ContextCompat.startForegroundService(
                    appContext,
                    android.content.Intent(appContext, fm.donmuse.app.playback.PlaybackService::class.java)
                )
                main.postDelayed({ Playback.setQueue(items, currentIndex.coerceIn(0, items.lastIndex), autoplay, (positionSeconds.coerceAtLeast(0.0) * 1000.0).toLong()) }, 700)
            } else {
                Playback.setQueue(items, currentIndex.coerceIn(0, items.lastIndex), autoplay, (positionSeconds.coerceAtLeast(0.0) * 1000.0).toLong())
            }
        }
    }

    @JavascriptInterface
    fun selectQueueItem(index: Int, autoplay: Boolean) {
        main.post { Playback.selectQueueItem(index, autoplay) }
    }

    @JavascriptInterface
    fun play() { main.post { Playback.play() } }

    @JavascriptInterface
    fun pause() { main.post { Playback.pause() } }

    @JavascriptInterface
    fun stop() { main.post { Playback.stop() } }

    @JavascriptInterface
    fun seekTo(seconds: Double) { main.post { Playback.seekTo((seconds * 1000.0).toLong()) } }

    @JavascriptInterface
    fun setVolume(value: Float) { main.post { Playback.setVolume(value.coerceIn(0f, 1f)) } }

    @JavascriptInterface
    fun setPlaybackRate(value: Float) { main.post { Playback.setPlaybackRate(value.coerceIn(0.5f, 3f)) } }

    @JavascriptInterface
    fun getPlaybackState(): String = PlaybackService.snapshotJson

    private fun isAllowedMediaUrl(value: String): Boolean = runCatching {
        val uri = android.net.Uri.parse(value)
        (uri.scheme == "https") || (uri.scheme == "http" && uri.host == "127.0.0.1" && uri.port == 3000)
    }.getOrDefault(false)
}
