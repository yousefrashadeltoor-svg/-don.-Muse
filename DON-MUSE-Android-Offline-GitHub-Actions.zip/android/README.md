# DON MUSE Android host

The Android application now hosts the **original DON MUSE Next.js website locally**. It is not a replacement Compose UI: `MainActivity` starts the embedded Node.js runtime and opens the original site from `http://127.0.0.1:3000`.

Native Android pieces remain alongside the website:

- Media3 playback service and system media notification.
- Home-screen mini-player and now-playing widgets.
- Android download handling for HTTP downloads.
- A JavaScript bridge that synchronizes the website queue with the native player.
- A persistent local PGlite database and web-bundle update mechanism.

## Supported build path

Use the repository-root guide `ANDROID-GITHUB-SETUP.md` and the workflow in `.github/workflows/android-apk.yml`. The workflow builds the original Next.js standalone server, downloads and verifies the pinned Android Node.js runtime, and assembles the APK.

The old `build-apk.sh` did not package the local website or Node runtime, so it has been removed to avoid producing an incomplete APK.
