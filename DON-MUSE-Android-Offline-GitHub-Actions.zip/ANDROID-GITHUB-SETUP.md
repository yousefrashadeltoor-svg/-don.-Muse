# DON MUSE — Android APK from GitHub Actions

This project keeps the **original Next.js website** as the app's primary interface. The Android shell starts a bundled Node.js runtime on `127.0.0.1:3000`, then opens that local site in WebView. The site source and UI are not replaced with a simplified native screen.

## Build your APK

1. Download this ZIP and extract it. Upload **the contents** to the root of a GitHub repository (not the ZIP file itself), on the `main` branch.
2. The repository must be **public** for the app's automatic website-update downloader to read the latest GitHub Release assets without a personal access token. Do not put a GitHub token inside the APK.
3. In GitHub open **Settings → Actions → General → Workflow permissions**, enable **Read and write permissions**, then save. This allows the web-update workflow to publish the latest bundle as a release asset.
4. Open **Actions**. Run **Build DON MUSE Android APK** if it did not start automatically. Also run **Publish DON MUSE offline web updates** if its first run did not start automatically.
5. When the APK workflow succeeds, open its run, scroll to **Artifacts**, and download `don-muse-android-apk`. Extract that artifact and install `app-debug.apk` on an Android device.

## Updating the website without reinstalling the APK

- Edit the existing website normally in `src/` or `public/`.
- Push the changes to `main`.
- **Publish DON MUSE offline web updates** builds the original Next.js standalone website and replaces the `donmuse-web-latest` GitHub Release assets.
- The Android app checks for a newer website bundle when it starts/returns to the foreground. It verifies SHA-256, stores the new bundle locally, and restarts only its isolated website process. The Android Media3 playback service and local PGlite database are kept separate.
- The phone must have internet temporarily to download a new bundle. Once downloaded, the website runs from local storage again.

Changes to Kotlin, C++, Android permissions, widgets, the notification service, or Media3 need a new APK. Website-only changes do not.

## Important real-world limits

- The website interface and local server are bundled in the APK. The local PGlite database is created on first launch and persists on that device. If you provide `data/seed.sql`, the build can include it as initial data. The repository currently contains no seed snapshot, so the first local database starts empty.
- Internet-dependent catalog search, online radio/TV, remote artwork not already cached, external embeds, and streaming sources still need internet. Downloaded/local files remain local.
- The current website has server routes that invoke `child_process` to run `yt-dlp`/Python and FFmpeg. The bundled Android Node runtime does not provide supported process spawning on Android, and the Linux FFmpeg executable is deliberately excluded from the Android bundle. Those extraction, transcoding, clipping, and download routes are **not yet Android-native/offline implementations**; they need a separate Android/JNI port. The original website pages remain present, but those specific server actions cannot be claimed to work offline on this APK.
- This build currently targets **arm64-v8a** and Android 8.0+ (minSdk 26).
- The app uses a foreground notification for its local Node website engine, in addition to Media3 playback notifications.

## What has and has not been verified here

The GitHub workflows, source layout, Android manifest XML, local health route, and packaging scripts are prepared for CI. This source-editing environment did not have the Android SDK/NDK/Gradle toolchain or the required Android device, so it did **not** produce or device-test an APK. The actual compile result will be reported by GitHub Actions.
